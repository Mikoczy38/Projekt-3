// 1. PO NAJETÍ MYŠI SE OBRÁZEK ZVĚTŠÍ A PO ODJETÍ ZMENŠÍ

const image1 = document.querySelector(".image1");
const image2 = document.querySelector(".image2");
const image3 = document.querySelector(".image3");

image1.addEventListener("mouseenter", () => {
  image1.style.transform = "scale(1.1)";
});
image1.addEventListener("mouseleave", () => {
  image1.style.transform = "scale(1)";
});

image2.addEventListener("mouseenter", () => {
  image2.style.transform = "scale(1.1)";
});
image2.addEventListener("mouseleave", () => {
  image2.style.transform = "scale(1)";
});

image3.addEventListener("mouseenter", () => {
  image3.style.transform = "scale(1.1)";
});
image3.addEventListener("mouseleave", () => {
  image3.style.transform = "scale(1)";
});

// 2. SVĚTLÝ A TMAVÝ MÓD

const body = document.querySelector("body");
const navigation = document.querySelector("nav");
const btn = document.querySelector(".btn");
const heading = document.querySelector("h1");

btn.addEventListener("click", () => {
  body.classList.toggle("theme-dark");
});

// 3. SCROLL ARROW

const arrow = document.querySelector(".scroll-arrow");
window.addEventListener("scroll", () => {
  if (window.scrollY > 200) {
    arrow.style.display = "block";
  } else {
    arrow.style.display = "none";
  }
});

// 4. KONTROLA HESLA VE FORMULÁŘI

const form = document.getElementById("form");
const password = document.querySelector(".password");
const resultText = document.querySelector(".span-text");
const correctPassword =
  "4fb86510d406085fc23b4976aee94c567dab976c2cca2a2fae1e81c96cf820cd";
const checkPassword = async (pw) => {
  const encoder = new TextEncoder();
  const data = encoder.encode(pw);
  const hash = await window.crypto.subtle.digest("SHA-256", data);
  const hashString = Array.from(new Uint8Array(hash))
    .map((v) => v.toString(16).padStart(2, "0"))
    .join("");
  if (hashString === correctPassword) {
    form.classList.add("valid");
    form.classList.remove("invalid");
    resultText.textContent = "Váše heslo je správné";
    resultText.style.color = "#00ff00";
  } else {
    form.classList.add("invalid");
    form.classList.remove("valid");
    resultText.textContent = "Váše heslo je nesprávné";
    resultText.style.color = "#ff0000";
  }
  if (password.value === "") {
    form.classList.remove("invalid");
    form.classList.remove("valid");
    resultText.textContent = "";
  }
};

password.addEventListener("input", () => {
  const passwordValue = password.value;
  checkPassword(passwordValue);
});
